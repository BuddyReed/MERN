const NotFound = props => {
    return (
        <h1 className="w-50 p-4 rounded mx-auto shadow mt-4">You Request Isn't Valid!</h1>
    );
}

export default NotFound;