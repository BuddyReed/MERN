
import './App.css';
import SomeClassComponent from './components/SomeClassComponent';

function App() {
  return (
    <div className="App">
      <SomeClassComponent lastName='Doe ' firstName='Jane' age='45' haircolor='Black' />
      <SomeClassComponent lastName='Smith ' firstName='John' age='88' haircolor='Brown' />
      <SomeClassComponent lastName='Filmore ' firstName='Millard' age='50' haircolor='Brown' />
      <SomeClassComponent lastName='Smith ' firstName='Maria' age='62' haircolor='Brown' />
    </div>
  );
}

export default App;
