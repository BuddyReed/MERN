import './App.css';
import React from 'react';

function App() {
  return (
    <div className="App">

      <h1 className='header'>Hello World</h1>
      <h2 className='subHead'>Things I need to do</h2>
      <ul>
        <li> Learn React</li>
        <li> Climb MT. Everest</li>
        <li> Run a marathon</li>
        <li> Feed the Dogs</li>
      </ul>

    </div>
  );
}

export default App;

